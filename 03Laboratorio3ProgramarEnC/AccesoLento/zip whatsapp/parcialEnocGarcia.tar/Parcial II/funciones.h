#ifndef _FUNCIONES_H
#define _FUNCIONES_H

int obtenerAleatorio(void);
void obtenerArrayAleatorio(int *arr, int size);
int obtenerAleatorioParam(int desde, int hasta);

#endif
