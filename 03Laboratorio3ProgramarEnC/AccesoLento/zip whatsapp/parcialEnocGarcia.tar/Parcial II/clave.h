#ifndef _CLAVE_H
#define _CLAVE_H

#include <sys/ipc.h>

key_t creo_clave(int);

#endif
