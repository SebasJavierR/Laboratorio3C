#ifndef _SHM_H
#define _SHM_H

void *creo_memoria(int, int *, int);

#endif
