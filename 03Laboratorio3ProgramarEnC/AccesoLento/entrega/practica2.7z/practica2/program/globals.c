/*Librerias*/
#include "pthread.h"

pthread_mutex_t mutex;
int cantidadJugadores;
int hormigasMaximas;
