# carrera
CARRERA(1) carrera 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 07/06/2023  

## NOMBRE
carrera

## OPCIONES
**carrera** no tiene opciones disponibles

## EJEMPLOS
**./carrera**

## VALORES DE SALIDA
**0**
: Éxito

---

# jugadores
JUGADORES(1) jugadores 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 07/06/2023  

## NOMBRE
jugadores

## OPCIONES
**jugadores** no tiene opciones disponibles

## EJEMPLOS
**./jugadores**

## VALORES DE SALIDA
**0**
: Éxito
