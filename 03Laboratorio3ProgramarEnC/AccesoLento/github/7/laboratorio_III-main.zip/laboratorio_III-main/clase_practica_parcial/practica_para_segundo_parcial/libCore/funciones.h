#ifndef _FUNCIONES_H
#define _FUNCIONES_H
char* obtenerCaracterPorNumero(int);
int obtenerNumeroPorCaracter(char*);
char* obtenerRutaArchivo(int);
#endif
