# reina
REINA(1) reina 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 07/06/2023  

## NOMBRE
reina

## OPCIONES
**reina [cantidad_hormigas]**

## EJEMPLOS
**./reina 4**

## VALORES DE SALIDA
**0**
: Éxito

---

# hormigas
HORMIGAS(1) hormigas 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 07/06/2023  

## NOMBRE
hormigas

## OPCIONES
**hormigas [cantidad_hormigas]**

## EJEMPLOS
**./hormigas 4**

## VALORES DE SALIDA
**0**
: Éxito
