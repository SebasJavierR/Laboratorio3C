/*Standard Library*/
#include "pthread.h"

pthread_mutex_t mutex;
int cantidadHormigas;
