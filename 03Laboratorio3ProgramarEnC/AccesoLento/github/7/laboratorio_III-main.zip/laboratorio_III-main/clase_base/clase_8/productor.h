#ifndef _PRODUCTOR_H
#define _PRODUCTOR_H
#include "globals.h"
void iniciarMemoria(dato*);
void iniciarMemoriaInicial(inicial*);
#endif
