#ifndef _FUNCIONES_H
#define _FUNCIONES_H
char* obtenerRutaArchivoMenu(int);
char* obtenerMenuLetra(int);
int obtenerMenuNum(char*);
int obtenerPrecioMenu(int);
char* obtenerCadenaPostre(int);
#endif
