# resto
RESTO(1) resto 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 20/06/2023  

## NOMBRE
resto

## OPCIONES
**resto** no tiene opciones disponibles

## EJEMPLOS
**./resto**

## VALORES DE SALIDA
**0**
: Éxito

---

# sdc
SDC(1) sdc 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 20/06/2023  

## NOMBRE
sdc

## OPCIONES
**sdc [A-C]**

## EJEMPLOS
**./sdc A**

## VALORES DE SALIDA
**0**
: Éxito
