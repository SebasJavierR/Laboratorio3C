# partido
PARTIDO(1) partido 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 20/06/2023  

## NOMBRE
partido

## OPCIONES
**partido**

## EJEMPLOS
**./partido**

## VALORES DE SALIDA
**0**
: Éxito

---

# jugador
JUGADOR(1) jugador 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 20/06/2023  

## NOMBRE
jugador

## OPCIONES
**jugador**

## EJEMPLOS
**./jugador**

## VALORES DE SALIDA
**0**
: Éxito
