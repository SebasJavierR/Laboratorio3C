#ifndef _CONSUMIDOR_H
#define _CONSUMIDOR_H
void leerDepositosCajero(int);
void backupLote(int, int);
void inicializarResumenes();
void imprimirResumen();
#endif
