#ifndef _CLAVES_H
#define _CLAVES_H
/*Standard Library*/
#include "sys/ipc.h"
key_t crearClave(int);
#endif
