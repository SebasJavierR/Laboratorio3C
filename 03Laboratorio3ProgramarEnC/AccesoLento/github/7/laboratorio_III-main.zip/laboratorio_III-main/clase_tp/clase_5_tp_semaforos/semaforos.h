#ifndef _SEMAFOROS_H
#define _SEMAFOROS_H
int creoSemaforo();
void iniciaSemaforo(int,int);
void levantaSemaforo(int);
void esperaSemaforo(int);
#endif
