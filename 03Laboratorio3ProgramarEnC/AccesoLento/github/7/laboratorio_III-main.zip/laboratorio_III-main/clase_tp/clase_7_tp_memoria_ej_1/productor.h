#ifndef _PRODUCTOR_H
#define _PRODUCTOR_H
#include "globals.h"
void iniciarMemoria(dato*);
void iniciarMemoriaInicial(inicial*);
void escribirNumeroPensado(dato*, int);
void escribirEstadoAcierto(dato*, int);
void escribirNombreJugador(dato*, char*);
#endif
