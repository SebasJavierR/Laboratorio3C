# Laboratorio_III
- Alternativa a VM: https://cocalc.com/
- Alternativa a CoCalc: https://www.online-ide.com/
  - Command line arguments: -Wall -O3 -std=gnu89 -pedantic-errors -pthread
  - Copiar todos los archivos con el mismo nombre y contenido.
  - Solo es para probar ejecución, no se puede observar creación de archivos.

## IPC
- Si cerramos un programa sin que termine de liberar los recursos compartidos. Debemos liberar estos recursos a mano.
- ipcs: https://www.man7.org/linux/man-pages/man1/ipcs.1.html
- ipcrm: https://www.man7.org/linux/man-pages/man1/ipcrm.1.html

## Abrir administrador de archivos desde la terminal 
- ```gnome-open .```
