#ifndef _FUNCIONES_H
#define _FUNCIONES_H
int obtenerNumeroAleatorio(int, int);
void obtenerNumerosAleatorios(int, int, int, int*);
void limpiarPantalla();
char* obtenerRutaArchivoPanel(int);
#endif
