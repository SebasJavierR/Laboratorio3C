#ifndef _PRODUCTOR_H
#define _PRODUCTOR_H
void escribirPanel();
void escribirMensajeDefaultPanel();
void inicializarPanel(int, int);
#endif
