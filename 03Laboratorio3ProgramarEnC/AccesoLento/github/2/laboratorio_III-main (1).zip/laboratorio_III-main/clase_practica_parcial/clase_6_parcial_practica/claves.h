#ifndef _CLAVES_H
#define _CLAVES_H
#define RUTA_ARCHIVO_FTOK "/bin/ls"
#include "sys/ipc.h"
key_t creoClave(int);
#endif
