#ifndef _FUNCIONES_H
#define _FUNCIONES_H
#define CANTIDAD 10
#define DESDE 0
#define HASTA 10
int obtenerNumeroAleatorio(int, int);
void obtenerNumerosAleatorios(int, int, int, int*);
char* obtenerDestino(int numVuelo);
#endif
