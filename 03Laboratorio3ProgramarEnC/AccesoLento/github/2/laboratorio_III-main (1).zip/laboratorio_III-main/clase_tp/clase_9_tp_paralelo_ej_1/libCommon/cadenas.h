#ifndef _CADENAS_H
#define _CADENAS_H
char letraMayuscula(char);
char letraMinuscula(char);
void cadenaMayuscula(char*, char*);
void cadenaMinuscula(char*, char*);
#endif
