#ifndef _CONSUMIDOR_H
#define _CONSUMIDOR_H
void funcionDummyConsumidor();
#endif
