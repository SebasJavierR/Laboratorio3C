/*Standard Library*/
#include "stdio.h"
/*File Header*/
#include "consumidor.h"

void funcionDummyConsumidor()
{
  printf("soy una función dummy\n");
}
