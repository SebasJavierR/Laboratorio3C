/*Standard Library*/
#include "stdio.h"
/*File Header*/
#include "productor.h"

void funcionDummyProductor()
{
  printf("soy una función dummy\n");
}
