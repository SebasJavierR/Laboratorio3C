/*Standard Library*/
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
/*Headers Library*/
#include "defines.h"
/*File Header*/
#include "funciones.h"

void funcionDummy()
{
  printf("soy una función dummy\n");
}
