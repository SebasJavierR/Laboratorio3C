#ifndef _PANTALLA_H
#define _PANTALLA_H
#define LINEAS_PANTALLA 80
void limpiarPantalla();
#endif
