#ifndef _CONSUMIDOR_H
#define _CONSUMIDOR_H
#include "globals.h"
void verificarMemoriaInicial(inicial*);
int leerNumeroPensado(dato*);
int leerEstadoAcierto(dato*);
char* leerNombreJugador(dato*);
#endif
