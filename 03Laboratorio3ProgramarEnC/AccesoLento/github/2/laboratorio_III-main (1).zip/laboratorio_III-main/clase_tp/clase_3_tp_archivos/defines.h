#ifndef _DEFINES_H_
#define _DEFINES_H_
#define RUTA_ARCHIVO_PRODUCTO "./producto.txt"
#define UNIDADES_LOTE 10
#define FALSE 0
#define TRUE 1
#endif
