# cajero
CAJERO(1) cajero 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 01/05/2023  

## NOMBRE
cajero

## SINOPSIS
**cajero**

## DESCRIPCIÓN
## OPCIONES
**cajero** no tiene opciones disponibles

## EJEMPLOS
**./cajero** [1-3]

## VALORES DE SALIDA
**0**
: Éxito

---

# tesorero
TESORERO(1) tesorero 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 01/05/2023  

## NOMBRE
tesorero

## SINOPSIS
**tesorero**

## DESCRIPCIÓN
## OPCIONES
**tesorero** no tiene opciones disponibles

## EJEMPLOS
**./tesorero**

## VALORES DE SALIDA
**0**
: Éxito
