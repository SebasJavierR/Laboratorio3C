#ifndef _MEMORIA_H
#define _MEMORIA_H
void* creoMemoria(int, int*, int);
void liberoMemoria(int, char*);
#endif
