# pienso
PIENSO(1) pienso 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 03/05/2023  

## NOMBRE
pienso

## SINOPSIS
**pienso**

## DESCRIPCIÓN

## OPCIONES
**pienso** no tiene opciones disponibles

## EJEMPLOS
**./pienso**

## VALORES DE SALIDA
**0**
: Éxito

---

# jugador
JUGADOR(1) jugador 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 03/05/2023  

## NOMBRE
jugador

## SINOPSIS
**jugador**

## DESCRIPCIÓN

## OPCIONES
**jugador** no tiene opciones disponibles

## EJEMPLOS
**./jugador**

## VALORES DE SALIDA
**0**
: Éxito
