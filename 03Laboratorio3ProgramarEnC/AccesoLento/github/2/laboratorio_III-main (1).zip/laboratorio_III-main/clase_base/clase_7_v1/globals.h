#ifndef _GLOBALS_H
#define _GLOBALS_H
struct tipo_dato
{
  int numero;
  char letra;
};
typedef struct tipo_dato dato;
#endif
