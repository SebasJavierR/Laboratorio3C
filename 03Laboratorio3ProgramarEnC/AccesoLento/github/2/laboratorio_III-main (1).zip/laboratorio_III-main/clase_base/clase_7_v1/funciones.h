#ifndef _FUNCIONES_H
#define _FUNCIONES_H
#include "defines.h"
int obtenerNumeroAleatorio(int, int);
void obtenerNumerosAleatorios(int, int, int, int*);
void limpiarPantalla();
char letraMayuscula(char);
char letraMinuscula(char);
void cadenaMayuscula(char*, char*);
void cadenaMinuscula(char*, char*);
#endif
