#ifndef _CONSUMIDOR_H
#define _CONSUMIDOR_H
#include "globals.h"
void verificarMemoriaIni(dato*);
void leerMemoria(dato*);
#endif
