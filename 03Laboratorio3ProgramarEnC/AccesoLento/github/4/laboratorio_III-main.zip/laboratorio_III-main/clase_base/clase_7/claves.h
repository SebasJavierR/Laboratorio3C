#ifndef _CLAVES_H
#define _CLAVES_H
#include "sys/ipc.h"
key_t creoClave(int);
#endif
