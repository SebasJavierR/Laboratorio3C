#ifndef _GLOBALS_H
#define _GLOBALS_H
struct tipo_dato
{
  int numero;
  char letra;
  int inicializado;
};
typedef struct tipo_dato dato;
#endif
