#ifndef _PRODUCTOR_H
#define _PRODUCTOR_H
#include "globals.h"
void iniciarMemoriaInicial(inicial*);
#endif
