#ifndef _FUNCIONES_H
#define _FUNCIONES_H
#include "defines.h"
int obtenerNumeroAleatorio(int, int);
void obtenerNumerosAleatorios(int, int, int, int*);
void limpiarPantalla();
char* obtenerRutaArchivoMenu(int);
char* obtenerMenuLetra(int);
int obtenerMenuNum(char*);
int obtenerPrecioMenu(int);
#endif
