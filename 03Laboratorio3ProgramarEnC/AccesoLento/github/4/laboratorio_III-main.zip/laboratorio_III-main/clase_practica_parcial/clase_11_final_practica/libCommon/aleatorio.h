#ifndef _ALEATORIO_H
#define _ALEATORIO_H
int obtenerNumeroAleatorio(int, int);
void obtenerNumerosAleatorios(int, int, int, int*);
#endif
