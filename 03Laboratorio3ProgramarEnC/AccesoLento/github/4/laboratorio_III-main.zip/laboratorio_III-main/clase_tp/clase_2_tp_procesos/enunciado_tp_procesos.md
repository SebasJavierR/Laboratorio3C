# Consignas
1. Realizar un programa que obtenga números aleatorios diferentes (no repetitivos): 
    1. Indicar el motivo por el cual el programa desarrollado es (o no) el óptimo. 
    2. Investigar y nombrar distintas maneras de realizar el mismo. 
    3. Ejecutarlo varias veces e identificar, desde consola, si se ejecuta con el mismo PID o no (ver comando PS).  
2. A partir del código realizado en el punto 1, confeccionar una función genérica que obtenga valores no repetitivos que sirva para futuros ejercicios (por ejemplo, puede devolver un vector con dichos valores). 
