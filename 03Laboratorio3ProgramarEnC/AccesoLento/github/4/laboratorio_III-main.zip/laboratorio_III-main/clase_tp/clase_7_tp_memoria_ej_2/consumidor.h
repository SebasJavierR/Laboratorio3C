#ifndef _CONSUMIDOR_H
#define _CONSUMIDOR_H
#include "globals.h"
void verificarMemoriaInicial(inicial*);
int leerVehiculosEnCola(dato*);
#endif
