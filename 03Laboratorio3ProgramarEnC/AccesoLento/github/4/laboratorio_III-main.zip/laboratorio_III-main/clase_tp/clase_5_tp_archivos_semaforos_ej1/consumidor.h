#ifndef _CONSUMIDOR_H
#define _CONSUMIDOR_H
int leerReservas();
void backupLote(int);
#endif
