#ifndef _PRODUCTOR_H
#define _PRODUCTOR_H
void escribirDeposito(int, int);
#endif
