#ifndef _MEMORIA_CORE_H
#define _MEMORIA_CORE_H
/*Headers Library*/
#include "globals.h"
void configurarMemoriaInicial(inicial*);
void verificarMemoriaInicial(inicial*);
#endif
