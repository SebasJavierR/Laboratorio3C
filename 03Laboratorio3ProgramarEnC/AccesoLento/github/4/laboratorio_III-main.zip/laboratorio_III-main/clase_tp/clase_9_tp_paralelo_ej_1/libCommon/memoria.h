#ifndef _MEMORIA_H
#define _MEMORIA_H
void* crearMemoria(int, int*, int);
void liberarMemoria(int, char*);
#endif
