# carrera
CARRERA(1) carrera 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 08/06/2023  

## NOMBRE
carrera

## OPCIONES
**carrera** no tiene opciones disponibles

## EJEMPLOS
**./carrera**

## VALORES DE SALIDA
**0**
: Éxito

---

# jugador
JUGADORES(1) jugador 1.0.0  
**Autor:** Andrés Isaac Biso  
**Fecha:** 08/06/2023  

## NOMBRE
jugador

## OPCIONES
**jugador** no tiene opciones disponibles

## EJEMPLOS
**./jugador**

## VALORES DE SALIDA
**0**
: Éxito
