#ifndef _PRODUCTOR_H
#define _PRODUCTOR_H
/*Headers Library*/
#include "globals.h"
void escribirOrden(comida*, int);
#endif
